"""
test_dummy_filter.py
--------------------
Diagnoses why Dummy App errors are not showing on the dashboard.

Run from the project root (the folder containing Application/, Dashboard/, etc.):
    cd "Log Aggregator"
    python test_dummy_filter.py
"""
import os
import sys
import json

ROOT           = os.path.dirname(os.path.abspath(__file__))
CONVERSION_DIR = os.path.join(ROOT, 'Conversion')
JSON_PATH      = os.path.join(CONVERSION_DIR, 'unique_errors.json')
LOG_PATH       = os.path.join(ROOT, 'Application', 'logs', 'application.log')
BP_PATH        = os.path.join(ROOT, 'Dashboard', 'dashboard_blueprint.py')

print("=" * 65)
print("DUMMY APP FILTER DIAGNOSTIC")
print("=" * 65)
print(f"Project root : {ROOT}")
print(f"Log path     : {LOG_PATH}")
print(f"JSON path    : {JSON_PATH}")

# 1. unique_errors.json
print("\n[1] unique_errors.json")
if not os.path.exists(JSON_PATH):
    print("    ERROR: NOT FOUND")
else:
    with open(JSON_PATH, encoding='utf-8') as f:
        errors = json.load(f)
    print(f"    Total errors in file : {len(errors)}")
    dummy = [e for e in errors if '/api/dummy' in e.get('API', '')]
    print(f"    Dummy app errors     : {len(dummy)}")
    for e in dummy:
        print(f"      code {e['Error Code']} | {e['API']} | count {e['Count']}")

# 2. application.log
print("\n[2] application.log")
if not os.path.exists(LOG_PATH):
    print(f"    ERROR: NOT FOUND at {LOG_PATH}")
    for dirpath, _, filenames in os.walk(ROOT):
        for fname in filenames:
            if fname == 'application.log':
                print(f"    Found at: {os.path.join(dirpath, fname)}")
else:
    with open(LOG_PATH, encoding='utf-8', errors='replace') as f:
        lines = f.readlines()
    dummy_lines = [l for l in lines if '/api/dummy' in l]
    print(f"    Total lines     : {len(lines)}")
    print(f"    Dummy app lines : {len(dummy_lines)}")
    for l in dummy_lines[-5:]:
        print(f"      {l.rstrip()}")

# 3. Filter check
print("\n[3] dashboard_blueprint.py filter")
if os.path.exists(BP_PATH):
    with open(BP_PATH, encoding='utf-8', errors='replace') as f:
        bp_src = f.read()
    if "filter_terms = ['/api/dummy/', 'dummy_app']" in bp_src:
        print("    OK: FIXED filter present")
    elif "source_filter.replace" in bp_src:
        print("    ERROR: OLD BROKEN filter - replace dashboard_blueprint.py and restart")
    else:
        print("    WARNING: Cannot determine filter state")

# 4. Write test line directly
print("\n[4] Writing test dummy error directly to log")
log_dir = os.path.join(ROOT, 'Application', 'logs')
try:
    os.makedirs(log_dir, exist_ok=True)
    test_lines = (
        '[2026-04-29T12:00:00] [INFO] GET /api/dummy/status IP: 10.0.0.1\n'
        "[2026-04-29T12:00:00] [ERROR] SSL certificate expired for domain api.dummy-app.internal {'error_code': 9010}\n"
        '[2026-04-29T12:00:00] [INFO] GET /api/dummy/status Status Code: 495\n'
    )
    with open(LOG_PATH, 'a', encoding='utf-8') as f:
        f.write(test_lines)
    print(f"    OK: Wrote 3 test lines to {LOG_PATH}")
except Exception as e:
    print(f"    ERROR: Write failed: {e}")
    sys.exit(1)

# 5. Run conversion
print("\n[5] Running conversion")
sys.path.insert(0, CONVERSION_DIR)
try:
    from log_to_csv_service import convert_log_to_rows, write_rows_to_csv, write_unique_errors_json
    rows = convert_log_to_rows(LOG_PATH)
    write_rows_to_csv(rows, os.path.join(CONVERSION_DIR, 'converted_application_logs.csv'))
    n = write_unique_errors_json(rows, JSON_PATH)
    print(f"    OK: {len(rows)} rows, {n} unique errors")
    with open(JSON_PATH, encoding='utf-8') as f:
        fresh = json.load(f)
    dummy_fresh = [e for e in fresh if '/api/dummy' in e.get('API', '')]
    print(f"    Dummy errors in JSON: {len(dummy_fresh)}")
    if dummy_fresh:
        print("    SUCCESS - restart Flask and the Dummy App filter will work")
        for e in dummy_fresh:
            print(f"      HTTP {e['Status Code']} code {e['Error Code']} | {e['API']}")
    else:
        print("    PROBLEM: conversion ran but no dummy errors in JSON")
        print("    Check log format above")
except Exception as e:
    print(f"    ERROR: {e}")
    import traceback; traceback.print_exc()

print("\n" + "=" * 65)
print("Next step: restart Flask (Ctrl+C then python app.py)")
print("Then visit http://localhost:5000/dashboard and click Dummy App")
print("=" * 65)