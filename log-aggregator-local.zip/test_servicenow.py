# test_servicenow.py
#
# Manual test script for the ServiceNow integration.
# Runs four tests: create, fetch, create-from-row, resolve.
#
# Usage:
#   python test_servicenow.py
#
# Requires SERVICENOW_INSTANCE, SERVICENOW_USERNAME, SERVICENOW_PASSWORD in .env
# Exit code 0 = all tests passed, 1 = failures.

import os
import sys
import traceback
from datetime import datetime, timezone

# Load .env from project root (same as app.py)
from dotenv import load_dotenv
load_dotenv(os.path.join(os.path.dirname(__file__), '.env'))

from servicenow_client import (
    create_incident,
    get_incident,
    resolve_incident,
    create_incident_from_row,
    is_configured,
    state_label,
)

GREEN = '\033[92m'
RED   = '\033[91m'
RESET = '\033[0m'
PASS  = f'{GREEN}✔ PASS{RESET}'
FAIL  = f'{RED}✖ FAIL{RESET}'

results = []


def run(name, fn):
    print(f'\n── {name} ──')
    try:
        result = fn()
        results.append((name, True))
        print(f'   {PASS}')
        return result
    except Exception as exc:
        results.append((name, False))
        print(f'   {FAIL}: {exc}')
        traceback.print_exc()
        return None


# ── Pre-flight ────────────────────────────────────────────────────────────────
if not is_configured():
    print(f'{RED}ERROR:{RESET} ServiceNow is not configured.')
    print('Add SERVICENOW_INSTANCE, SERVICENOW_USERNAME, SERVICENOW_PASSWORD to .env')
    sys.exit(1)

print('ServiceNow configuration found — running tests...')


# ── Test 1: Create incident ───────────────────────────────────────────────────
def test_create():
    ts = datetime.now(timezone.utc).isoformat()
    incident = create_incident(
        short_description=f'[TEST] Log Aggregator integration test {ts}',
        description=f'Automated test from test_servicenow.py\nSafe to close.\nTimestamp: {ts}',
        severity='low',
        source_app='dummy_app',
        error_code='9999',
    )
    assert incident.get('sys_id'), 'No sys_id in response'
    print(f'   number={incident["number"]}  sys_id={incident["sys_id"]}')
    return incident


created = run('Test 1 — Create incident', test_create)
sys_id  = created.get('sys_id') if created else None


# ── Test 2: Fetch incident ────────────────────────────────────────────────────
def test_fetch():
    assert sys_id, 'Skipped — no sys_id from Test 1'
    inc = get_incident(sys_id)
    assert inc.get('sys_id') == sys_id
    print(f'   number={inc["number"]}  state={state_label(inc["state"])}')
    return inc


run('Test 2 — Fetch incident by sys_id', test_fetch)


# ── Test 3: Create from dashboard error row ───────────────────────────────────
def test_from_row():
    row = {
        'Status Code': '503',
        'Error Code':  '2001',
        'Description': 'Toil sensor gateway did not respond within SLA threshold',
        'API':         'GET /api/dummy_app/sensors',
        'Last Seen':   datetime.now(timezone.utc).isoformat(),
    }
    inc = create_incident_from_row(row)
    assert inc.get('sys_id')
    print(f'   number={inc["number"]}  sys_id={inc["sys_id"]}')
    return inc


run('Test 3 — Create incident from dashboard row', test_from_row)


# ── Test 4: Resolve incident from Test 1 ──────────────────────────────────────
def test_resolve():
    assert sys_id, 'Skipped — no sys_id from Test 1'
    result = resolve_incident(sys_id, close_notes='Closed by test_servicenow.py — safe to delete.')
    assert str(result.get('state')) == '6', f'Expected state=6, got {result.get("state")}'
    print(f'   state={state_label(result["state"])}')


run('Test 4 — Resolve incident', test_resolve)


# ── Summary ───────────────────────────────────────────────────────────────────
print('\n' + '═' * 50)
print('RESULTS')
print('═' * 50)
for name, ok in results:
    print(f'  {"PASS" if ok else "FAIL"}  {name}')
passed = sum(1 for _, ok in results if ok)
failed = len(results) - passed
print(f'\n  {passed} passed, {failed} failed')
print('═' * 50)
sys.exit(0 if failed == 0 else 1)