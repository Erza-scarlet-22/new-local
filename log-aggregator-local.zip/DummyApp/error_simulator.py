# Dummy-infra-app/error_simulator.py
#
# FIXED:
#   - Writes ONLY to ssl_events.log (the dedicated events file shipped to S3)
#   - Does NOT write to the full application.log (which has health check noise)
#   - Log format matches log_parser.py regex exactly so Lambda parses it correctly

import random
from datetime import datetime, timezone


class ErrorSimulator:
    """
    Writes structured error / resolution log entries to the dedicated
    ssl_events.log file.  Format matches log_parser.py regex patterns
    so the Lambda processor parses them into the dashboard automatically.
    """

    ERROR_DEFINITIONS = {
        "ssl_expired": (
            495, 9010,
            "SSL certificate expired for domain api.dummy-app.internal",
            "GET /api/dummy/status",
        ),
        "ssl_expiring": (
            200, 9011,
            "SSL certificate expires in 7 days for domain api.dummy-app.internal",
            "GET /api/dummy/status",
        ),
        "password_expired": (
            401, 9012,
            "Service account password expired, authentication failed",
            "POST /api/dummy/auth",
        ),
        "db_storage": (
            507, 9013,
            "Database storage at 92% capacity, writes may fail",
            "POST /api/dummy/db-write",
        ),
        "db_connection": (
            504, 9014,
            "RDS connection pool exhausted, timeout after 30s",
            "GET /api/dummy/db-read",
        ),
        "compute_overload": (
            503, 9015,
            "CPU at 95%, memory at 88%, dropping requests",
            "POST /api/dummy/process",
        ),
    }

    RESOLUTION_MESSAGES = {
        "ssl_expired":      "SSL certificate renewed successfully. New cert ARN stored in Secrets Manager.",
        "ssl_expiring":     "SSL certificate rotated proactively. 90 days until next expiry.",
        "password_expired": "Service account password rotated via Secrets Manager. Auth reconnected.",
        "db_storage":       "RDS allocated storage increased. New capacity applied successfully.",
        "db_connection":    "RDS instance class upgraded. Connection pool limits increased.",
        "compute_overload": "ECS desired count increased. Additional tasks launched and healthy.",
    }

    def __init__(self, logger, events_log_file: str):
        """
        events_log_file: path to ssl_events.log  (NOT the full app log)
        """
        self._logger          = logger
        self._events_log_file = events_log_file

    def _ts(self) -> str:
        return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")

    def _fake_ip(self) -> str:
        return (f"10.{random.randint(0,255)}"
                f".{random.randint(0,255)}"
                f".{random.randint(1,254)}")

    def generate_error(self, error_type: str) -> str:
        """
        Write a 3-line log entry to ssl_events.log matching log_parser.py format:
          Line 1: request arrival   → matched by API_WITH_IP_PATTERN
          Line 2: error detail      → matched by ERROR_CODE_PATTERN
          Line 3: response status   → matched by STATUS_PATTERN (emits the row)
        Returns line 2 (the ERROR line).
        """
        if error_type not in self.ERROR_DEFINITIONS:
            raise ValueError(f"Unknown error_type: {error_type}. "
                             f"Valid: {list(self.ERROR_DEFINITIONS)}")

        http_code, err_code, description, api_path = self.ERROR_DEFINITIONS[error_type]
        ts = self._ts()
        ip = self._fake_ip()

        line1 = f"[{ts}] [INFO] {api_path} IP: {ip}"
        line2 = f"[{ts}] [ERROR] {description} {{'error_code': {err_code}}}"
        line3 = f"[{ts}] [INFO] {api_path} Status Code: {http_code}"

        self._write_lines([line1, line2, line3])
        self._logger.info("Event written to %s: %s (code=%d)",
                          self._events_log_file, error_type, err_code)
        return line2

    def generate_resolution(self, error_type: str, details: dict) -> str:
        """Write a RESOLVED line to ssl_events.log and return it."""
        ts  = self._ts()
        msg = self.RESOLUTION_MESSAGES.get(error_type, f"{error_type} resolved.")
        if details:
            cert = details.get("cert_arn", "")
            if cert:
                msg += f" Cert ARN: {cert[-30:]}"

        line = f"[{ts}] [INFO] RESOLVED: {msg}"
        self._write_lines([line])
        self._logger.info("Resolution written: %s", error_type)
        return line

    def _write_lines(self, lines: list) -> None:
        """Append lines to the events log file."""
        try:
            with open(self._events_log_file, "a", encoding="utf-8") as f:
                for line in lines:
                    f.write(line + "\n")
        except OSError as exc:
            self._logger.error("Failed to write to events log %s: %s",
                               self._events_log_file, exc)
            raise