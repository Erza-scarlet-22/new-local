# dummy_app_final.py
#
# Generates realistic application logs for the Toilet Management dummy service.
# Writes to Application/logs/application.log using the EXACT 3-line format that
# log_to_csv_service.convert_log_to_rows() expects, so conversion and the
# dashboard work with zero changes.
#
# Log format per event (mirrors simulator.py):
#   [YYYY-MM-DDTHH:MM:SS] [INFO]  METHOD /path IP: x.x.x.x
#   [YYYY-MM-DDTHH:MM:SS] [ERROR] <description> {'error_code': NNNN}
#   [YYYY-MM-DDTHH:MM:SS] [INFO]  METHOD /path Status Code: NNN
#
# Usage:
#   python dummy_app_final.py              # run continuously (Ctrl+C to stop)
#   python dummy_app_final.py --burst 50   # emit 50 events then exit
#   python dummy_app_final.py --burst 50 --interval 0  # as fast as possible

import argparse
import os
import random
import time
from datetime import datetime

# ── Resolve log path relative to this file (sits at project root) ────────────
_HERE    = os.path.dirname(os.path.abspath(__file__))
_LOG_DIR = os.path.join(_HERE, 'Application', 'logs')
_LOG_FILE = os.path.join(_LOG_DIR, 'application.log')

os.makedirs(_LOG_DIR, exist_ok=True)

# ── Source tag written into every log line ────────────────────────────────────
SOURCE_TAG = 'dummy_app'

# ── Error scenarios: (http_status, error_code, description, api_path) ─────────
# Error codes are in the 2000-series to avoid colliding with existing scenarios.
_ERROR_SCENARIOS = [
    (503, 2001, 'Toilet sensor gateway did not respond within SLA threshold',   f'GET  /api/{SOURCE_TAG}/sensors'),
    (500, 2002, 'Database connection pool exhausted — all connections in use',   f'POST /api/{SOURCE_TAG}/flush'),
    (404, 2003, 'Toilet unit not found in registry',                             f'GET  /api/{SOURCE_TAG}/unit/{{id}}'),
    (422, 2004, 'Maintenance schedule payload missing required field: unit_id',  f'POST /api/{SOURCE_TAG}/maintenance'),
    (401, 2005, 'Authentication token expired for maintenance crew dashboard',   f'POST /api/{SOURCE_TAG}/auth'),
    (409, 2006, 'Flush command rejected — unit TLT-009 is already in flush cycle', f'POST /api/{SOURCE_TAG}/flush'),
    (502, 2007, 'Received malformed response from downstream sensor aggregator', f'GET  /api/{SOURCE_TAG}/sensors'),
    (504, 2008, 'Upstream alert engine timed out after 3000 ms',                 f'GET  /api/{SOURCE_TAG}/alerts'),
    (429, 2009, 'Rate limit exceeded for sensor heartbeat endpoint',             f'POST /api/{SOURCE_TAG}/heartbeat'),
    (500, 2010, 'NullPointerException in pressure reading parser',               f'GET  /api/{SOURCE_TAG}/sensors'),
]

# ── Successful (2xx) scenarios emitted for realism ────────────────────────────
_SUCCESS_SCENARIOS = [
    (200, f'GET  /api/{SOURCE_TAG}/status'),
    (200, f'GET  /api/{SOURCE_TAG}/sensors'),
    (201, f'POST /api/{SOURCE_TAG}/maintenance'),
    (200, f'GET  /api/{SOURCE_TAG}/alerts'),
    (200, f'POST /api/{SOURCE_TAG}/heartbeat'),
]


def _fake_ip() -> str:
    return f"10.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"


def _now_ts() -> str:
    return datetime.now().strftime('%Y-%m-%dT%H:%M:%S')


def _write_error_event(fh, http_status: int, error_code: int, description: str, api: str):
    """Write the exact 3-line format the log parser expects for an error event."""
    ts = _now_ts()
    ip = _fake_ip()
    fh.write(f"[{ts}] [INFO] {api} IP: {ip}\n")
    fh.write(f"[{ts}] [ERROR] {description} {{'error_code': {error_code}}}\n")
    fh.write(f"[{ts}] [INFO] {api} Status Code: {http_status}\n")
    fh.flush()


def _write_success_event(fh, http_status: int, api: str):
    """Write a 3-line success event (no error line needed by the parser, but kept for consistency)."""
    ts = _now_ts()
    ip = _fake_ip()
    fh.write(f"[{ts}] [INFO] {api} IP: {ip}\n")
    fh.write(f"[{ts}] [INFO] {api} Status Code: {http_status}\n")
    fh.flush()


def emit_event(fh):
    """Emit one weighted random event to the open file handle."""
    # ~25% errors, ~75% successes — realistic ratio
    if random.random() < 0.25:
        scenario = random.choice(_ERROR_SCENARIOS)
        _write_error_event(fh, *scenario)
    else:
        status, api = random.choice(_SUCCESS_SCENARIOS)
        _write_success_event(fh, status, api)


def main():
    parser = argparse.ArgumentParser(description='Toilet Mgmt dummy app log generator')
    parser.add_argument('--burst',    type=int,   default=0,   help='Emit N events then exit (0 = run forever)')
    parser.add_argument('--interval', type=float, default=0.5, help='Seconds between events (default 0.5)')
    parser.add_argument('--log',      default=_LOG_FILE,       help='Override log file path')
    args = parser.parse_args()

    log_path = args.log
    os.makedirs(os.path.dirname(os.path.abspath(log_path)), exist_ok=True)

    print(f"[dummy_app] Writing to: {log_path}")
    print(f"[dummy_app] Source tag : {SOURCE_TAG}")
    if args.burst:
        print(f"[dummy_app] Burst mode : {args.burst} events")
    else:
        print(f"[dummy_app] Continuous mode — Ctrl+C to stop")

    with open(log_path, 'a', encoding='utf-8') as fh:
        ts = _now_ts()
        fh.write(f"[{ts}] [INFO] dummy_app started {'burst=' + str(args.burst) if args.burst else 'continuous'}\n")
        fh.flush()

        if args.burst:
            for _ in range(args.burst):
                emit_event(fh)
                if args.interval:
                    time.sleep(args.interval)
            ts = _now_ts()
            fh.write(f"[{ts}] [INFO] dummy_app burst complete events={args.burst}\n")
            fh.flush()
            print(f"[dummy_app] Done — {args.burst} events written.")
        else:
            count = 0
            try:
                while True:
                    emit_event(fh)
                    count += 1
                    if args.interval:
                        time.sleep(args.interval)
            except KeyboardInterrupt:
                ts = _now_ts()
                fh.write(f"[{ts}] [INFO] dummy_app stopped events={count}\n")
                fh.flush()
                print(f"\n[dummy_app] Stopped — {count} events written.")


if __name__ == '__main__':
    main()